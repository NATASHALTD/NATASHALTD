$(function(){
	/*=============formstyle============*/
	$(".sex_select, .okno_3 input[type='checkbox'], .okno_20_1_div2_div2_div_ch, .okno_20_select, .okno_20_2_div2_1_div_r").styler({
		selectSearch: true,
	});
	$('[data-toggle="popover"]').popover();
});