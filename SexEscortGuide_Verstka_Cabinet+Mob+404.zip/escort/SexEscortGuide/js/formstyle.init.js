$(function(){
	/*formstyle*/
	$('.okno_6_c_div_2_div_select').styler({
		selectSearch: true,
	});
});