$("document").ready(function(){
    $('.anchor').anchor({
        transitionDuration : 1200
    });
});