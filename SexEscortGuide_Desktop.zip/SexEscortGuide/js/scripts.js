
$( document ).ready(function(  ) {
	$( '.slider-pro' ).sliderPro({
		width: 387,
		height: 578,
		fade: true,
		arrows: false,
		buttons: false,
		fullScreen: false,
		shuffle: false,
		thumbnailArrows: false,
		thumbnailTouchSwipe: true,
		thumbnailWidth: 123, 
		thumbnailHeight: 138,
		autoplay: false
	});
});

