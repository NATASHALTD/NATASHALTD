$( document ).ready(function(  ) {
	$( '.slider-pro' ).sliderPro({
		width: 450,
		height: 673,
		fade: true,
		arrows: false,
		buttons: false,
		fullScreen: false,
		shuffle: false,
		thumbnailArrows: false,
		thumbnailTouchSwipe: true,
		thumbnailWidth: 143, 
		thumbnailHeight: 159,
		autoplay: false
	});
});

