$(function(){
	/*=============formstyle============*/
	$(".sex_select, .okno_3 input[type='checkbox']").styler({
		selectSearch: true,
	});
});